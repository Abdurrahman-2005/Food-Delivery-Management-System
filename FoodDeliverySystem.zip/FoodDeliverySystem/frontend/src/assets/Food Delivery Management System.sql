UPDATE RESTAURANT
SET password = '$2b$12$3x3Wn53YfpG1p5FoRKSerOsQe.gaigktlvUWT4OMtw6YO1KyaRg46'
WHERE email = 'cheezious@help.com';