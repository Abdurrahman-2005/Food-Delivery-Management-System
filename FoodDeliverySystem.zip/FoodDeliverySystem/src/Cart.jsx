import { useEffect, useState } from "react";
import { Container, Typography } from "@mui/material";
import SelectItem from "./SelectItem";

export default function Cart() {
  const [storedItems, setStoredItems] = useState([]);

  useEffect(() => {
    const items = Object.keys(localStorage).map(key => ({
      key,
      value: localStorage.getItem(key)
    }));
    setStoredItems(items);
  }, []);

  return (
    <Container>
      {storedItems.map(({ key, value }) => (
        <Typography key={key}>{`${key}: ${value}`}</Typography>
      ))}

      <SelectItem label={"Payment Type"} items={[[12, "COD"]]} />
      <SelectItem label={"Select Address"} items={[[16, "Islamabad"], [17, "Lahore"]]} />
    </Container>
  );
}
