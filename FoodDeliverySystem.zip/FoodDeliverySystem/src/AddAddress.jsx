import { useState, useEffect } from 'react'; 
import axios from 'axios'; 
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Radio from '@mui/material/Radio'; 
import IconButton from '@mui/material/IconButton';
import DeleteIcon from '@mui/icons-material/Delete';

export default function AddAddress() {
  const [data, setData] = useState([]);
  let customerID = 61;
  // Fetch addresses
  useEffect(() => {
    const fetchData = async () => {
      try {
        customerID = parseInt(localStorage.getItem("customer"));
        console.log("customer id "+customerID);
        const response = await axios.post("http://localhost:3000/customer/address", {customerID: customerID});
        console.log(response.data);
        setData(response.data);
      } catch (error) {
        console.error(error);
      }
    };
    fetchData();
  }, []);
  
  // Track single selected address ID
  const [selectedValue, setSelectedValue] = useState(null);

  // Handle radio selection
  const handleSelect = (addressId) => () => {
    setSelectedValue(addressId);
  };
  const deleteAddress = async (addressID)=> {
      try {
        await axios.delete("http://localhost:3000/customer/address", addressID);
      } catch (error) {
        console.error(error);
    }
  }
  return (
    <List sx={{ width: '100%', bgcolor: 'background.paper' }}>
      {data?.map((address) => {
        const labelId = `radio-list-label-${address[0]}`; // Updated to radio

        return (
          <ListItem
            sx={{width:"100%"}}
            key={61}
            secondaryAction={
              <IconButton edge="end" aria-label="delete" onClick={()=>{deleteAddress(address[0]);}}>
                <DeleteIcon style={{ color: 'red', fontSize: 20 }} />
              </IconButton>
            }
            disablePadding
          >
            <ListItemButton 
              role={undefined} 
              onClick={handleSelect(address[0])} 
              dense
            >
              <ListItemIcon>
                <Radio
                  edge="start"
                  checked={selectedValue === address[0]}
                  tabIndex={-1}
                  disableRipple
                  inputProps={{ 
                    'aria-labelledby': labelId,
                    'role': 'radio' 
                  }}
                />
              </ListItemIcon>
              <ListItemText sx={{width:"100%"}}
                id={labelId} 
                primary={`${address[2]}, ${address[3]}`} 
              />
            </ListItemButton>
          </ListItem>
        );
      })}
    </List>
  );
}
