import { useForm } from 'react-hook-form';
import axios from 'axios';
import Form from './Form';
export default function Signin({ toggleAuthMode, setSignedIn, setAccountType }) {
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();

  const onSubmit = async (formData) => {
    try {
      if (formData.accountType === "customer") {
      const response = await axios.post("http://localhost:3000/customer", formData);
      if (response.data.length>0) {
        console.log(response.data[0][1]);
        localStorage.setItem("customer", response.data[0][1]);
        localStorage.setItem("customerName", response.data[0][0]);
        localStorage.setItem("cart", JSON.stringify([]));
        setSignedIn(true);
      }
      console.log(response);
      } else {
        const response = await axios.post("http://localhost:3000/restaurant", formData);
        if (response.data.length > 0) {
        localStorage.setItem("restaurant", response.data[0][1]);
        localStorage.setItem("restaurantName", response.data[0][0]);
        setAccountType("restaurant");
        }
      console.log(response);
      }
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <Form
      handler={{
        handleSubmit,
        onSubmit,
        register,
        label: 'Sign in',
        inputs: ["email", "password"],
        linkText: "Don't have an account? Sign up",
        toggleAuthMode,
        isSubmitted: false,
      }}
    />
  );
}