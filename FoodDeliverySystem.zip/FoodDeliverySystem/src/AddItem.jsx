import { useState } from 'react';
import Card from '@mui/material/Card';
import CardActions from '@mui/material/CardActions';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import { CardMedia, TextField } from '@mui/material';
export default function AddItem() {
  const [photo, setPhoto] = useState("");
   const handleChange = (event) => {
    setPhoto(event.target.value);
  };
  return (
    <Card sx={{ minWidth: 275, maxWidth: 700 }}>
     <CardContent>
        {photo.length !== 0 && (
          <CardMedia sx={{ height: 140 }} image={photo} title="dish" />
        )}
        <div className="form-fields" style={{
          display:"flex", flexDirection:"column", gap:"16px"
        }}>
          <TextField label="Name" variant="outlined" fullWidth />
          <TextField
            label="Description"
            multiline
            rows={4}
            defaultValue="Enter a description of the product"
            fullWidth
          />
          <TextField
            label="Photo URL"
            variant="outlined"
            onChange={handleChange}
            fullWidth
          />
          <TextField label="Price" variant="outlined" fullWidth />
          <TextField label="Quantity" type="number" fullWidth />
        </div>
      </CardContent>

      <CardActions>
        <Button size="small">Add</Button>
      </CardActions>
    </Card>
  );
}