import { useForm } from 'react-hook-form';
import { useState, useEffect } from "react";
import Form from './Form';
import axios from 'axios';
export default function Signup({ toggleAuthMode, signedIn, setSignedIn, setAccountType }) {
  const [data, setData] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const onSubmit = (formData) => {
    setData(formData);
    console.log(data);
  };
  useEffect(()=>{
    if (Object.keys(data).length > 0) {
      setIsSubmitted(true);
    }
  }, [data]);
  const finalSubmit = async (formData) => {
    try {
      if (data.accountType==="customer") {
      const response1 = await axios.post("http://localhost:3000/customers", data);
      console.log(response1);
      if (response1.data.length>0) {
        localStorage.setItem("customer", response1.data.customer_id[0]);
        localStorage.setItem("cart", JSON.stringify([]));
      }
      const response2 = await axios.post("http://localhost:3000/customers/addresses", {customer_id: response1.data.customer_id[0], ...formData});
      console.log(response2);
      setSignedIn(true);
      } else {
        const response = await axios.post("http://localhost:3000/restaurants", {...data, ...formData});
        if (response.data.length > 0) {
        localStorage.setItem("restaurant", response.data.restaurant_id[0]);
        localStorage.setItem("restaurantName", response.data.restaurant_id[0]);
        }
        console.log(response);
        setAccountType("restaurant");
      }
    } catch (error) {
      console.error(error);
    }
  }
  return (
    <>
    {!isSubmitted && <Form
      handler={{
        showLink: true,
        handleSubmit:handleSubmit,
        onSubmit:onSubmit,
        register:register,
        isSubmitted: false,
        label: "Sign Up",
        inputs: ["name", "email", "password"],
        linkText: "Already have an account? Sign in",
        toggleAuthMode:toggleAuthMode,
        nameInput: true,
        signedIn:signedIn
      }}
    />
    }
    {isSubmitted && <Form handler={{
        showLink: false,
        handleSubmit:handleSubmit,
        isSubmitted: true,
        finalSubmit:finalSubmit,
        register: register,
        label: "Sign Up",
        inputs: data.accountType === "customer"?  ["address1", "address2", "postal_code", "city", "phone_number"] : ["city"],
        linkText: "Already have an account? Sign in",
        toggleAuthMode:toggleAuthMode,
        nameInput: true,
        signedIn: signedIn
      }}/> }
    </>
  );
}
