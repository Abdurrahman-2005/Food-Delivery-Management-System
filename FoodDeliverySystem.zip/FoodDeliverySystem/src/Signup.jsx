import { useForm } from 'react-hook-form';
import { useState, useEffect } from "react";
import Form from './Form';
import axios from 'axios';
export default function Signup({ toggleAuthMode, setSignedIn, setAccountType }) {
  const [data, setData] = useState({});
  const [isSubmitted, setIsSubmitted] = useState(false);
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm();
  const onSubmit = (formData) => {
    setData(formData);
    console.log(data);
  };
  useEffect(()=>{
    if (Object.keys(data).length > 0) {
      setIsSubmitted(true);
    }
  }, [data]);
  const finalSubmit = async (formData) => {
    try {
      if (data.accountType==="customer") {
      const response1 = await axios.post("http://localhost:3000/customer/new", data);
      console.log(response1);
      if (response1.data.length>0) {
        console.log(response1.data[0][1]);
        localStorage.setItem("customer", response1.data[0][1]);
        localStorage.setItem("customerName", response1.data[0][0]);
        localStorage.setItem("cart", JSON.stringify([]));
      }
      const response2 = await axios.post("http://localhost:3000/customer/address/new", {customerID: response1.data[0][1], ...formData});
      console.log(response2);
      setSignedIn(true);
      } else {
        const response = await axios.post("http://localhost:3000/restaurant/new", {...data, ...formData});
        if (response.data.length > 0) {
        localStorage.setItem("restaurant", response.data[0][1]);
        localStorage.setItem("restaurantName", response.data[0][0]);
        }
        console.log(response);
        setAccountType("resstaurant");
      }
    } catch (error) {
      console.error(error);
    }
  }
  return (
    <>
    {!isSubmitted && <Form
      handler={{
        handleSubmit,
        onSubmit,
        register,
        isSubmitted: false,
        label: "Sign Up",
        inputs: ["name", "email", "password"],
        linkText: "Already have an account? Sign in",
        toggleAuthMode,
        nameInput: true,
      }}
    />
    }
    {isSubmitted && <Form handler={{
        handleSubmit:handleSubmit,
        isSubmitted: true,
        finalSubmit:finalSubmit,
        register,
        label: "Sign Up",
        inputs: data.accountType === "customer"?  ["address1", "address2", "postalCode", "city", "phoneNumber"] : ["city"],
        linkText: "Already have an account? Sign in",
        toggleAuthMode,
        nameInput: true,
      }}/> }
    </>
  );
}
