import { useEffect, useState } from 'react';
import Signin from './Signin';
import Signup from './Signup';

export default function AuthContainer({ defaultAuth, setSignedIn, setAccountType }) {
  const [isSignIn, setIsSignIn] = useState(defaultAuth);
  useEffect(() => {
    setIsSignIn(defaultAuth);
  }, [defaultAuth]);

  const toggleAuthMode = () => setIsSignIn(prev => !prev);

  return (
    <>
      {isSignIn ? (
        <Signin toggleAuthMode={toggleAuthMode} setSignedIn={setSignedIn}  setAccountType={setAccountType}/>
      ) : (
        <Signup toggleAuthMode={toggleAuthMode} setSignedIn={setSignedIn}  setAccountType={setAccountType}/>
      )}
    </>
  );
}
