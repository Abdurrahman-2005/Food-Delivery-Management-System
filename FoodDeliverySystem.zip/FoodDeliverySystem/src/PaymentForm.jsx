import CardActions from '@mui/material/CardActions';
import TextField from '@mui/material/TextField';
import { Button } from '@mui/material';
import { Typography } from '@mui/material';
import { useState } from 'react';
export default function PaymentForm({paymentType, handleChange, element, quantity, setQuantity, price}) {
  const[added, setAdded] = useState(false);
    return (
        <CardActions sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
          <TextField
            id="filled-number"
            label="Quantity"
            type="number"
            variant="filled"
            value={quantity}
            onChange={(e) => setQuantity(Number(e.target.value))}
            InputLabelProps={{ shrink: true }}
            sx={{ width: 120 }}
            inputProps={{ min: 1 }}
          />
          <Typography gutterBottom variant="h5" component="div">{"Price: " + price*quantity}</Typography>
          <Button variant="contained" onClick={()=>{
            let cart = JSON.parse(localStorage.getItem("cart")) || [];
            cart.push([...element, quantity]);
            localStorage.setItem("cart", JSON.stringify(cart));
            setAdded(true);
          }}>{added? "Added": "Add To Cart"}</Button>
        </CardActions>
    );
}