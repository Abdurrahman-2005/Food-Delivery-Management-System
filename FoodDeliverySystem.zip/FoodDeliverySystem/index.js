import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import oracledb from "oracledb";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = 3000;
const configureDBObject = {
    user: "C##food_delivery",
    password: "pass",
    connectString: "localhost/XEPDB1"
}
app.use(express.json());
app.use(express.static(path.join(__dirname, 'dist')));
app.get("/restaurants/dishes", async (req, res)=> {
    console.log("GET CUSTOMER MENU");
    let database;
    let response;
    const SQL = "SELECT * FROM DISH";
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(SQL);
         if (response.rows.length === 0) res.status(201).send([[]]);
         else {
         console.log("Success");
         res.json(response.rows);
         }
        } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.get("/restaurants/dishes/:restaurant_id", async (req, res)=> {
    console.log("GET RESTAURANT MENU");
    const {restaurant_id} = req.params;
    let database;
    let response;
    const SQL = "SELECT * FROM DISH WHERE restaurant_id = :restaurant_id";
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(SQL, {restaurant_id},
            {autoCommit: true });
         if (response.rows.length === 0) res.status(201).send([[]]);
         else {
         console.log("Success");
         res.json(response.rows);
         }
        } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.post("/restaurants/dishes", async (req, res) => {
  console.log("ADD A NEW DISH MENU");
  const { restaurant_id, name, description, photo_url, price, quantity } = req.body;
  let database;

  const SQL_INSERT = `
    INSERT INTO DISH (restaurant_id, name, description, photo_url, price, quantity)
    VALUES (:restaurant_id, :name, :description, :photo_url, :price, :quantity)
    RETURNING dish_id INTO :dish_id
  `;

  try {
    database = await oracledb.getConnection(configureDBObject);

    const result = await database.execute(
      SQL_INSERT,
      {
        restaurant_id,
        name,
        description,
        photo_url,
        price,
        quantity,
        dish_id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
      },
      { autoCommit: true }
    );

    const dish_id = result.outBinds.dish_id;
    console.log("Inserted dish ID:", dish_id);

    res.status(201).json({
      message: "Dish added successfully",
      dish_id: dish_id
    });

  } catch (e) {
    console.error("Error adding dish:", e);
    res.status(500).json({ error: "Internal server error" });
  } finally {
    try {
      if (database) await database.close();
    } catch (e) {
      console.error("Error closing DB:", e);
    }
  }
})

app.delete("/restaurants/dishes/:dish_id", async (req, res)=> {
    console.log("DELETE DISH");
    const {dish_id} = req.params;
    if (!dish_id) res.status(400).send([[]]);
    console.log("Dish id: "+dish_id);
    let database;
    let response;
    const SQL = "DELETE FROM DISH WHERE dish_id = :dish_id";
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(SQL, {dish_id},
            {autoCommit: true });
         if (response.rowsAffected === 1) res.status(201).send([[]]);
         else {
         console.log("Failed");
         res.json(response.rows);
         }
        } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});

app.post("/auth/customers", async (req, res) => {
    console.log("LOGIN CUSTOMER");
    const { email, password } = req.body;
    let database;
    let response;

    const SQL = "SELECT customer_id FROM CUSTOMER WHERE email = :email AND password = :password";

    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(
            SQL,
            { email, password },
            { autoCommit: true }
        );

        if (response.rows.length === 0) {
            res.status(401).json({ error: "Invalid email or password" });
        } else {
            const customer_id = response.rows[0][0];
            console.log("Login Success, customer ID:", customer_id);

            res.json({ customer_id });
        }
    } catch (e) {
        console.error("Login error:", e);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        try {
            if (database) await database.close();
        } catch (e) {
            console.error("Error closing DB:", e);
        }
    }
});

app.post("/auth/restaurants", async (req, res) => {
    console.log("LOGIN RESTAURANT");
    const { email, password } = req.body;
    let database;
    let response;

    const SQL = "SELECT restaurant_id FROM RESTAURANT WHERE email = :email AND password = :password";

    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(
            SQL,
            { email, password },
            { autoCommit: true }
        );
        if (response.rows.length === 0) {
            res.status(401).json({ error: "Invalid email or password" });
        } else {
            const restaurant_id = response.rows[0][0];
            console.log("Login Success, restaurant ID:", restaurant_id);

            res.json({ restaurant_id });
        }
    } catch (e) {
        console.error("Login error:", e);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        try {
            if (database) await database.close();
        } catch (e) {
            console.error("Error closing DB:", e);
        }
    }
});

app.post("/customers", async (req, res) => {
    console.log("CREATE NEW CUSTOMER");
    const { name, email, password } = req.body;
    let database;

    const SQL_INSERT = `
        INSERT INTO CUSTOMER (name, email, password)
        VALUES (:name, :email, :password)
        RETURNING customer_id INTO :customer_id
    `;

    try {
        database = await oracledb.getConnection(configureDBObject);

        const result = await database.execute(
            SQL_INSERT,
            {
                name,
                email,
                password,
                customer_id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
            },
            { autoCommit: true }
        );
        const customer_id = result.outBinds.customer_id;
        console.log("Inserted customer ID:", customer_id);

        res.status(201).json({
            message: "Customer created successfully",
            customer_id: customer_id
        });

    } catch (e) {
        console.error("Error creating customer:", e);
        if (e.errorNum === 1) {
            res.status(409).json({ error: "Email already in use" });
        } else {
            res.status(500).json({ error: "Internal server error" });
        }

    } finally {
        try {
            if (database) await database.close();
        } catch (e) {
            console.error("Error closing DB:", e);
        }
    }
});

app.post("/restaurants", async (req, res) => {
    console.log("CREATE NEW RESTAURANT");
    const { name, email, password, city } = req.body;
    let database;

    const SQL_INSERT = `
        INSERT INTO RESTAURANT (name, email, password, city)
        VALUES (:name, :email, :password, :city)
        RETURNING restaurant_id INTO :restaurant_id
    `;

    try {
        database = await oracledb.getConnection(configureDBObject);

        const result = await database.execute(
            SQL_INSERT,
            {
                name,
                email,
                password,
                city,
                restaurant_id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
            },
            { autoCommit: true }
        );

        const restaurant_id = result.outBinds.restaurant_id;
        console.log("Inserted restaurant ID:", restaurant_id);

        res.status(201).json({
            message: "Restaurant created successfully",
            restaurant_id: restaurant_id
        });

    } catch (e) {
        console.error("Error creating restaurant:", e);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        try {
            if (database) await database.close();
        } catch (e) {
            console.error("Error closing DB:", e);
        }
    }
});

app.get("/customers/addresses/:customer_id", async (req, res)=> {
    console.log("GET CUSTOMER ADDESSES");
    console.log(req.body);
    const {customer_id} = req.params;
    let database;
    let response;
    const SQL = "SELECT * FROM CUSTOMERADDRESS WHERE customer_id = :customer_id";
    console.log(customer_id);
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(SQL, {customer_id});
        console.log(response);
         if (response.rows.length === 0) res.status(201).send([[]]);
         else {
         console.log("Success");
         res.json(response.rows);
         }
        } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.delete("/customers/addresses/:address_id", async (req, res)=> {
    console.log("DELETE CUSTOMER ADDRESSES");
    const {address_id} = req.params;
    if (!address_id) return res.status(400).json({ error: "address_id is required" });
    let database;
    let response;
    const SQL = "DELETE FROM CUSTOMERADDRESS WHERE address_id = :address_id";
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(SQL, {address_id}, {autoCommit: true});
         if (response.rowsAffected === 1) {
            console.log("Deleted");
            res.status(200).json({ success: true });
        } else {
            res.status(404).json({ error: "Address not found or already deleted" });
        }
    } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.post("/customers/addresses", async (req, res) => {
    console.log("CREATE NEW CUSTOMER ADDRESS");
    const { customer_id, address1, address2, postal_code, city, phone_number } = req.body;
    let database;

    const SQL_INSERT = `
        INSERT INTO CUSTOMERADDRESS (
            customer_id, address1, address2, postal_code, city, phone_number
        ) VALUES (
            :customer_id, :address1, :address2, :postal_code, :city, :phone_number
        )
        RETURNING address_id INTO :address_id
    `;

    try {
        database = await oracledb.getConnection(configureDBObject);

        const result = await database.execute(
            SQL_INSERT,
            {
                customer_id,
                address1,
                address2,
                postal_code,
                city,
                phone_number,
                address_id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
            },
            { autoCommit: true }
        );

        const address_id = result.outBinds.addressID;
        console.log("Inserted address ID:", address_id);

        res.status(201).json({
            message: "Customer address added successfully",
            address_id: address_id
        });

    } catch (e) {
        console.error("Error inserting customer address:", e);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        try {
            if (database) await database.close();
        } catch (e) {
            console.error("Error closing DB:", e);
        }
    }
});
app.post("/orders", async (req, res) => {
    console.log("NEW ORDER");
    const { customer_id, restaurant_id, address_id, paymentType } = req.body;
    let database;

    const SQL_INSERT = `
        INSERT INTO "ORDER" (customer_id, restaurant_id, address_id, order_date, payment_type)
        VALUES (:customer_id, :restaurant_id, :address_id, SYSDATE, :paymentType)
        RETURNING order_id INTO :order_id
    `;

    try {
        database = await oracledb.getConnection(configureDBObject);

        const result = await database.execute(
            SQL_INSERT,
            {
                customer_id,
                restaurant_id,
                address_id,
                paymentType,
                order_id: { type: oracledb.NUMBER, dir: oracledb.BIND_OUT }
            },
            { autoCommit: true }
        );

        const order_id = result.outBinds.order_id;
        console.log("Inserted order ID:", order_id);

        res.status(201).json({ order_id });

    } catch (e) {
        console.error("Error creating new order:", e);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        try {
            if (database) await database.close();
        } catch (e) {
            console.error("Error closing DB:", e);
        }
    }
});
app.post("/orders/items", async (req, res) => {
    console.log("NEW ITEMS ORDER");
    const { order_id, dish_id, quantity, price } = req.body;
    let database;

    const SQL_INSERT = `
        INSERT INTO ORDERITEM (order_id, dish_id, quantity, price)
        VALUES (:order_id, :dish_id, :quantity, :price)
    `;

    try {
        database = await oracledb.getConnection(configureDBObject);

        const result = await database.execute(
            SQL_INSERT,
            { order_id, dish_id, quantity, price },
            { autoCommit: true }
        );

        res.status(201).json(result);

    } catch (e) {
        console.error("Error creating new order:", e);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        try {
            if (database) await database.close();
        } catch (e) {
            console.error("Error closing DB:", e);
        }
    }
});


app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});
app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});