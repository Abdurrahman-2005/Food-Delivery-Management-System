import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import oracledb from "oracledb";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = 3000;
const configureDBObject = {
    user: "C##food_delivery",
    password: "pass",
    connectString: "localhost/XEPDB1"
}
app.use(express.json());
app.use(express.static(path.join(__dirname, 'dist')));
app.get("/customer", async (req, res)=> {
    console.log("GET CUSTOMER MENU");
    let database;
    let response;
    const SQL = "SELECT * FROM DISH";
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(SQL);
         if (response.rows.length === 0) res.status(201).send([[]]);
         else {
         console.log("Success");
         res.json(response.rows);
         }
        } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.post("/restaurant/dish", async (req, res)=> {
    console.log("GET RESTAURANT MENU");
    const {restaurantID} = req.body;
    let database;
    let response;
    const SQL = "SELECT * FROM DISH WHERE restaurant_id = :restaurantID";
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(SQL, {restaurantID},
            {autoCommit: true });
         if (response.rows.length === 0) res.status(201).send([[]]);
         else {
         console.log("Success");
         res.json(response.rows);
         }
        } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.post("/restaurant/dish/new", async (req, res) => {
  console.log("ADD A NEW DISH MENU");
  const { restaurantID, name, description, photoURL, price, quantity } = req.body;
  let database;

  const SQL_INSERT = `
    INSERT INTO DISH (restaurant_id, name, description, photo_url, price, quantity)
    VALUES (:restaurantID, :name, :description, :photoURL, :price, :quantity)
    RETURNING dish_id INTO :dishID
  `;

  try {
    database = await oracledb.getConnection(configureDBObject);

    const result = await database.execute(
      SQL_INSERT,
      {
        restaurantID,
        name,
        description,
        photoURL,
        price,
        quantity,
        dishID: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
      },
      { autoCommit: true }
    );

    const dishID = result.outBinds.dishID;
    console.log("Inserted dish ID:", dishID);

    res.status(201).json({
      message: "Dish added successfully",
      dish_id: dishID
    });

  } catch (e) {
    console.error("Error adding dish:", e);
    res.status(500).json({ error: "Internal server error" });
  } finally {
    try {
      if (database) await database.close();
    } catch (e) {
      console.error("Error closing DB:", e);
    }
  }
});

app.post("/restaurant/dish/delete", async (req, res)=> {
    console.log("DELETE DISH");
    const {dishID} = req.body;
    if (!dishID) res.status(400).send([[]]);
    console.log("Dish id: "+dishID);
    let database;
    let response;
    const SQL = "DELETE FROM DISH WHERE dish_id = :dishID";
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(SQL, {dishID},
            {autoCommit: true });
         if (response.rowsAffected === 1) res.status(201).send([[]]);
         else {
         console.log("Failed");
         res.json(response.rows);
         }
        } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});

app.post("/customer", async (req, res) => {
    console.log("LOGIN CUSTOMER");
    const { email, password } = req.body;
    let database;
    let response;

    const SQL = "SELECT customer_id FROM CUSTOMER WHERE email = :email AND password = :password";

    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(
            SQL,
            { email, password },
            { autoCommit: true }
        );

        console.log(response);

        if (response.rows.length === 0) {
            res.status(401).json({ error: "Invalid email or password" });
        } else {
            const customerID = response.rows[0][0];
            console.log("Login Success, customer ID:", customerID);

            res.json({ customerID });
        }
    } catch (e) {
        console.error("Login error:", e);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        try {
            if (database) await database.close();
        } catch (e) {
            console.error("Error closing DB:", e);
        }
    }
});

app.post("/restaurant", async (req, res) => {
    console.log("LOGIN RESTAURANT");
    const { email, password } = req.body;
    let database;
    let response;

    const SQL = "SELECT restaurant_id FROM RESTAURANT WHERE email = :email AND password = :password";

    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(
            SQL,
            { email, password },
            { autoCommit: true }
        );

        console.log(response);

        if (response.rows.length === 0) {
            res.status(401).json({ error: "Invalid email or password" });
        } else {
            const restaurantID = response.rows[0][0];
            console.log("Login Success, restaurant ID:", restaurantID);

            res.json({ restaurantID });
        }
    } catch (e) {
        console.error("Login error:", e);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        try {
            if (database) await database.close();
        } catch (e) {
            console.error("Error closing DB:", e);
        }
    }
});

app.post("/customer/new", async (req, res) => {
    console.log("CREATE NEW CUSTOMER");
    const { name, email, password } = req.body;
    let database;

    const SQL_INSERT = `
        INSERT INTO CUSTOMER (name, email, password)
        VALUES (:name, :email, :password)
        RETURNING customer_id INTO :customerID
    `;

    try {
        database = await oracledb.getConnection(configureDBObject);

        const result = await database.execute(
            SQL_INSERT,
            {
                name,
                email,
                password,
                customerID: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
            },
            { autoCommit: true }
        );
        const customerID = result.outBinds.customerID;
        console.log("Inserted customer ID:", customerID);

        res.status(201).json({
            message: "Customer created successfully",
            customerID: customerID
        });

    } catch (e) {
        console.error("Error creating customer:", e);
        if (e.errorNum === 1) {
            res.status(409).json({ error: "Email already in use" });
        } else {
            res.status(500).json({ error: "Internal server error" });
        }

    } finally {
        try {
            if (database) await database.close();
        } catch (e) {
            console.error("Error closing DB:", e);
        }
    }
});

app.post("/restaurant/new", async (req, res) => {
    console.log("CREATE NEW RESTAURANT");
    const { name, email, password, city } = req.body;
    let database;

    const SQL_INSERT = `
        INSERT INTO RESTAURANT (name, email, password, city)
        VALUES (:name, :email, :password, :city)
        RETURNING restaurant_id INTO :restaurantID
    `;

    try {
        database = await oracledb.getConnection(configureDBObject);

        const result = await database.execute(
            SQL_INSERT,
            {
                name,
                email,
                password,
                city,
                restaurant_id: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
            },
            { autoCommit: true }
        );

        const restaurantID = result.outBinds.restaurantID;
        console.log("Inserted restaurant ID:", restaurantID);

        res.status(201).json({
            message: "Restaurant created successfully",
            restaurantID: restaurantID
        });

    } catch (e) {
        console.error("Error creating restaurant:", e);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        try {
            if (database) await database.close();
        } catch (e) {
            console.error("Error closing DB:", e);
        }
    }
});

app.post("/customer/address", async (req, res)=> {
    console.log("GET CUSTOMER ADDESSES");
    console.log(req.body);
    const {customerID} = req.body;
    let database;
    let response;
    const SQL = "SELECT * FROM CUSTOMERADDRESS WHERE customer_id = :customerID";
    console.log(customerID);
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(SQL, {customerID});
        console.log(response);
         if (response.rows.length === 0) res.status(201).send([[]]);
         else {
         console.log("Success");
         res.json(response.rows);
         }
        } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.post("/customer/address/delete", async (req, res)=> {
    console.log("DELETE CUSTOMER ADDRESSES");
    const {addressID} = req.body;
    if (!addressID) return res.status(400).json({ error: "addressID is required" });
    let database;
    let response;
    const SQL = "DELETE FROM CUSTOMERADDRESS WHERE address_id = :addressID";
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(SQL, {addressID}, {autoCommit: true});
         if (response.rowsAffected === 1) {
            console.log("Deleted");
            res.status(200).json({ success: true });
        } else {
            res.status(404).json({ error: "Address not found or already deleted" });
        }
    } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.post("/customer/address/new", async (req, res) => {
    console.log("CREATE NEW CUSTOMER ADDRESS");
    const { customerID, address1, address2, postalCode, city, phoneNumber } = req.body;
    let database;

    const SQL_INSERT = `
        INSERT INTO CUSTOMERADDRESS (
            customer_id, address1, address2, postal_code, city, phone_number
        ) VALUES (
            :customerID, :address1, :address2, :postalCode, :city, :phoneNumber
        )
        RETURNING address_id INTO :addressID
    `;

    try {
        database = await oracledb.getConnection(configureDBObject);

        const result = await database.execute(
            SQL_INSERT,
            {
                customerID,
                address1,
                address2,
                postalCode,
                city,
                phoneNumber,
                addressID: { dir: oracledb.BIND_OUT, type: oracledb.NUMBER }
            },
            { autoCommit: true }
        );

        const addressID = result.outBinds.addressID;
        console.log("Inserted address ID:", addressID);

        res.status(201).json({
            message: "Customer address added successfully",
            address_id: addressID
        });

    } catch (e) {
        console.error("Error inserting customer address:", e);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        try {
            if (database) await database.close();
        } catch (e) {
            console.error("Error closing DB:", e);
        }
    }
});
app.post("/order/new", async (req, res) => {
    console.log("NEW ORDER");
    const { customerID, restaurantID, addressID, paymentType } = req.body;
    let database;

    const SQL_INSERT = `
        INSERT INTO "ORDER" (customer_id, restaurant_id, address_id, order_date, payment_type)
        VALUES (:customerID, :restaurantID, :addressID, SYSDATE, :paymentType)
        RETURNING order_id INTO :orderID
    `;

    try {
        database = await oracledb.getConnection(configureDBObject);

        const result = await database.execute(
            SQL_INSERT,
            {
                customerID,
                restaurantID,
                addressID,
                paymentType,
                orderID: { type: oracledb.NUMBER, dir: oracledb.BIND_OUT }
            },
            { autoCommit: true }
        );

        const orderID = result.outBinds.orderID;
        console.log("Inserted order ID:", orderID);

        res.status(201).json({ orderID });

    } catch (e) {
        console.error("Error creating new order:", e);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        try {
            if (database) await database.close();
        } catch (e) {
            console.error("Error closing DB:", e);
        }
    }
});
app.post("/order/item/new", async (req, res) => {
    console.log("NEW ITEMS ORDER");
    const { orderID, dishID, quantity, price } = req.body;
    let database;

    const SQL_INSERT = `
        INSERT INTO ORDERITEM (order_id, dish_id, quantity, price)
        VALUES (:orderID, :dishID, :quantity, :price)
    `;

    try {
        database = await oracledb.getConnection(configureDBObject);

        const result = await database.execute(
            SQL_INSERT,
            { orderID, dishID, quantity, price },
            { autoCommit: true }
        );

        res.status(201).json(result);

    } catch (e) {
        console.error("Error creating new order:", e);
        res.status(500).json({ error: "Internal server error" });
    } finally {
        try {
            if (database) await database.close();
        } catch (e) {
            console.error("Error closing DB:", e);
        }
    }
});


app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});
app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});