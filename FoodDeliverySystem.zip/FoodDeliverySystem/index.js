import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import oracledb from "oracledb";
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();
const PORT = 3000;
const configureDBObject = {
    user: "C##food_delivery",
    password: "pass",
    connectString: "localhost/XEPDB1"
}
app.use(express.json());
app.use(express.static(path.join(__dirname, 'dist')));
app.get("/customer", async (req, res)=> {
    console.log("GET CUSTOMER MENU");
    let database;
    let response;
    const SQL = "SELECT * FROM DISH";
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(SQL);
         if (response.rows.length === 0) res.status(201).send([[]]);
         else {
         console.log("Success");
         res.json(response.rows);
         }
        } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.post("/restaurant/dish", async (req, res)=> {
    console.log("GET RESTAURANT MENU");
    const {restaurantID} = req.body;
    let database;
    let response;
    const SQL = "SELECT * FROM DISH WHERE restaurant_id = :restaurantID";
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(SQL, {restaurantID},
            {autoCommit: true });
         if (response.rows.length === 0) res.status(201).send([[]]);
         else {
         console.log("Success");
         res.json(response.rows);
         }
        } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.post("/restaurant/dish/delete", async (req, res)=> {
    console.log("DELETE DISH");
    const {dishID} = req.body;
    console.log("Dish id: "+dishID);
    let database;
    let response;
    const SQL = "DELETE FROM DISH WHERE dish_id = :dishID";
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(SQL, {dishID},
            {autoCommit: true });
         if (response.rows.length === 0) res.status(201).send([[]]);
         else {
         console.log("Success");
         res.json(response.rows);
         }
        } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});

app.post("/customer", async (req, res)=> {
    console.log("LOGIN CUSTOMER");
    const { email, password } = req.body;
    let database;
    let response;
    const SQL = "SELECT name, customer_id FROM CUSTOMER WHERE email = :email AND password = :password";
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(
            SQL,
            {email, password},
            {autoCommit: true }
         );
         console.log(response);
         if (response.rows.length === 0) res.status(201).send([[]]);
         else {
         console.log("Success");
         res.json(response.rows);
         }
        } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.post("/restaurant", async (req, res)=> {
    console.log("LOGIN RESTAURANT");
    const { email, password } = req.body;
    let database;
    let response;
    const SQL = "SELECT name, restaurant_id FROM RESTAURANT WHERE email = :email AND password = :password";
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(
            SQL,
            {email, password},
            {autoCommit: true }
         );
         console.log(response);
         if (response.rows.length === 0) res.status(201).send([[]]);
         else {
         console.log("Success");
         res.json(response.rows);
         }
        } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.post("/customer/new", async (req, res)=> {
    console.log("CREATE NEW CUSTOMER");
    const { name, email, password } = req.body;
    let database;
    let response;
    const SQL1 = "INSERT INTO CUSTOMER ( name, email, password) VALUES (:name, :email, :password)";
    const SQL2 = "Select name, customer_id FROM CUSTOMER where email = :email";
    try {
        database = await oracledb.getConnection(configureDBObject);
        await database.execute(
            SQL1, 
            {name, email, password},
            {autoCommit: true }
         );
        response = await database.execute(
            SQL2,
            {email},
            {autoCommit: true }
         );
         console.log(response);
         if (response.rows.length === 0) res.status(201).send([[]]);
         else {
         console.log(response);
         console.log("Success");
         res.json(response.rows);
         }
    } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.post("/restaurant/new", async (req, res)=> {
    console.log("CREATE NEW RESTAURANT");
    const { name, email, password } = req.body;
    let database;
    let response;
    const SQL1 = "INSERT INTO RESTAURANT ( name, email, password) VALUES (:name, :email, :password)";
    const SQL2 = "Select name, restaurant_id FROM RESTAURANT where email = :email";
    try {
        database = await oracledb.getConnection(configureDBObject);
        await database.execute(
            SQL1, 
            {name, email, password},
            {autoCommit: true }
         );
        response = await database.execute(
            SQL2,
            {email},
            {autoCommit: true }
         );
         console.log(response);
         if (response.rows.length === 0) res.status(201).send([[]]);
         else {
         console.log(response);
         console.log("Success");
         res.json(response.rows);
         }
    } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.post("/customer/address", async (req, res)=> {
    console.log("GET CUSTOMER ADDESSES");
    console.log(req.body);
    const {customerID} = req.body;
    let database;
    let response;
    const SQL = "SELECT * FROM CUSTOMERADDRESS WHERE customer_id = :customerID";
    console.log(customerID);
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(SQL, {customerID});
        console.log(response);
         if (response.rows.length === 0) res.status(201).send([[]]);
         else {
         console.log("Success");
         res.json(response.rows);
         }
        } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.delete("/customer/address", async (req, res)=> {
    console.log("DELETE CUSTOMER ADDRESSES");
    const {addressID} = req.body;
    let database;
    let response;
    const SQL = "DROP FROM CUSTOMERADDRESS WHERE address_id = :addressID";
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(SQL, {addressID});
         if (response.rows.length === 0) res.status(201).send([[]]);
         else {
         console.log("Success");
         res.json(response.rows);
         }
        } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.post("/customer/address/new", async (req, res)=> {
    console.log("CREATE NEW CUSTOMER ADDRESSS");
    const {customerID, address1, address2, postalCode, city, phoneNumber} = req.body;
    let database;
    let response;
    const SQL = "INSERT INTO CUSTOMERADDRESS (customer_id, address1, address2, postal_code, city, phone_number) VALUES (:customerID, :address1, :address2, :postalCode, :city, :phoneNumber)";
    try {
        database = await oracledb.getConnection(configureDBObject);
        response = await database.execute(SQL, {customerID, address1, address2, postalCode, city, phoneNumber});
        console.log("User Addrress added");
         res.status(202).send("Success");
        } catch(e) {
        console.log(e);
    } finally {
        try {
            if (database) await database.close();
        } catch(e) {
            console.log(e);
        }
    }
});
app.use((req, res) => {
  res.sendFile(path.join(__dirname, 'dist', 'index.html'));
});
app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});